package com.example.uccitmobileapp.db

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.example.uccitmobileapp.data.StaffMember
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_ID
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_STAFF_EMAIL
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_STAFF_NAME
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_STAFF_PHONE
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_STAFF_PHOTO
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_STAFF_POSITION
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.TABLE_STAFF

class StaffRepository(context: Context) {
    private val dbHelper = DatabaseHelper(context)

    fun getAllStaff(): List<StaffMember> {
        val staffList = mutableListOf<StaffMember>()
        val db = dbHelper.readableDatabase

        val cursor = db.query(
            TABLE_STAFF,
            null,
            null,
            null,
            null,
            null,
            "$COLUMN_STAFF_NAME ASC"
        )

        while (cursor.moveToNext()) {
            staffList.add(cursorToStaffMember(cursor))
        }

        cursor.close()
        db.close()
        return staffList
    }

    fun getStaffMemberById(id: Long): StaffMember? {
        val db = dbHelper.readableDatabase
        var staffMember: StaffMember? = null

        val cursor = db.query(
            TABLE_STAFF,
            null,
            "$COLUMN_ID = ?",
            arrayOf(id.toString()),
            null,
            null,
            null
        )

        if (cursor.moveToFirst()) {
            staffMember = cursorToStaffMember(cursor)
        }

        cursor.close()
        db.close()
        return staffMember
    }

    fun insertStaffMember(staffMember: StaffMember): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_STAFF_NAME, staffMember.name)
            put(COLUMN_STAFF_POSITION, staffMember.position)
            put(COLUMN_STAFF_PHONE, staffMember.phoneNumber)
            put(COLUMN_STAFF_EMAIL, staffMember.email)
            put(COLUMN_STAFF_PHOTO, staffMember.photoUrl)
        }

        val id = db.insert(TABLE_STAFF, null, values)
        db.close()
        return id
    }

    fun updateStaffMember(staffMember: StaffMember): Int {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_STAFF_NAME, staffMember.name)
            put(COLUMN_STAFF_POSITION, staffMember.position)
            put(COLUMN_STAFF_PHONE, staffMember.phoneNumber)
            put(COLUMN_STAFF_EMAIL, staffMember.email)
            put(COLUMN_STAFF_PHOTO, staffMember.photoUrl)
        }

        val rowsAffected = db.update(
            TABLE_STAFF,
            values,
            "$COLUMN_ID = ?",
            arrayOf(staffMember.id.toString())
        )

        db.close()
        return rowsAffected
    }

    fun deleteStaffMember(id: Long): Int {
        val db = dbHelper.writableDatabase
        val rowsAffected = db.delete(
            TABLE_STAFF,
            "$COLUMN_ID = ?",
            arrayOf(id.toString())
        )

        db.close()
        return rowsAffected
    }

    private fun cursorToStaffMember(cursor: Cursor): StaffMember {
        val idIndex = cursor.getColumnIndex(COLUMN_ID)
        val nameIndex = cursor.getColumnIndex(COLUMN_STAFF_NAME)
        val positionIndex = cursor.getColumnIndex(COLUMN_STAFF_POSITION)
        val phoneIndex = cursor.getColumnIndex(COLUMN_STAFF_PHONE)
        val emailIndex = cursor.getColumnIndex(COLUMN_STAFF_EMAIL)
        val photoIndex = cursor.getColumnIndex(COLUMN_STAFF_PHOTO)

        return StaffMember(
            id = cursor.getLong(idIndex),
            name = cursor.getString(nameIndex),
            position = cursor.getString(positionIndex),
            phoneNumber = cursor.getString(phoneIndex),
            email = cursor.getString(emailIndex),
            photoUrl = cursor.getString(photoIndex)
        )
    }
}