package com.example.uccitmobileapp.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.uccitmobileapp.fragments.FacebookFragment
import com.example.uccitmobileapp.fragments.InstagramFragment
import com.example.uccitmobileapp.fragments.TwitterFragment

class SocialMediaPagerAdapter(fragmentActivity: FragmentActivity) :
    FragmentStateAdapter(fragmentActivity) {

    override fun getItemCount(): Int = 3

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> FacebookFragment()
            1 -> TwitterFragment()
            2 -> InstagramFragment()
            else -> FacebookFragment()
        }
    }
}