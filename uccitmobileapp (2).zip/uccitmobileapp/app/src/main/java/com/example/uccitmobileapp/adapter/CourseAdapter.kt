package com.example.uccitmobileapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.uccitmobileapp.R
import com.example.uccitmobileapp.data.Course

class CourseAdapter(
    private var courseList: List<Course>,
    private val onItemClick: (Course) -> Unit
) : RecyclerView.Adapter<CourseAdapter.CourseViewHolder>() {

    class CourseViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val codeTextView: TextView = view.findViewById(R.id.text_course_code)
        val nameTextView: TextView = view.findViewById(R.id.text_course_name)
        val creditsTextView: TextView = view.findViewById(R.id.text_course_credits)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CourseViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_course, parent, false)
        return CourseViewHolder(view)
    }

    override fun onBindViewHolder(holder: CourseViewHolder, position: Int) {
        val course = courseList[position]

        holder.codeTextView.text = course.code
        holder.nameTextView.text = course.name
        holder.creditsTextView.text = "${course.credits} credits"

        holder.itemView.setOnClickListener {
            onItemClick(course)
        }
    }

    override fun getItemCount() = courseList.size

    fun updateCourseList(newCourseList: List<Course>) {
        courseList = newCourseList
        notifyDataSetChanged()
    }
}