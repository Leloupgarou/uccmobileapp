package com.example.uccitmobileapp.db

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.example.uccitmobileapp.data.Course
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_COURSE_CODE
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_COURSE_CREDITS
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_COURSE_DESCRIPTION
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_COURSE_NAME
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_COURSE_PREREQUISITES
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.COLUMN_ID
import com.example.uccitmobileapp.db.DatabaseHelper.Companion.TABLE_COURSES

class CourseRepository(context: Context) {
    private val dbHelper = DatabaseHelper(context)

    fun getAllCourses(): List<Course> {
        val courses = mutableListOf<Course>()
        val db = dbHelper.readableDatabase

        val cursor = db.query(
            TABLE_COURSES,
            null,
            null,
            null,
            null,
            null,
            "$COLUMN_COURSE_CODE ASC"
        )

        while (cursor.moveToNext()) {
            courses.add(cursorToCourse(cursor))
        }

        cursor.close()
        db.close()
        return courses
    }

    fun getCourseById(id: Long): Course? {
        val db = dbHelper.readableDatabase
        var course: Course? = null

        val cursor = db.query(
            TABLE_COURSES,
            null,
            "$COLUMN_ID = ?",
            arrayOf(id.toString()),
            null,
            null,
            null
        )

        if (cursor.moveToFirst()) {
            course = cursorToCourse(cursor)
        }

        cursor.close()
        db.close()
        return course
    }

    fun insertCourse(course: Course): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_COURSE_CODE, course.code)
            put(COLUMN_COURSE_NAME, course.name)
            put(COLUMN_COURSE_CREDITS, course.credits)
            put(COLUMN_COURSE_PREREQUISITES, course.prerequisites)
            put(COLUMN_COURSE_DESCRIPTION, course.description)
        }

        val id = db.insert(TABLE_COURSES, null, values)
        db.close()
        return id
    }

    fun updateCourse(course: Course): Int {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_COURSE_CODE, course.code)
            put(COLUMN_COURSE_NAME, course.name)
            put(COLUMN_COURSE_CREDITS, course.credits)
            put(COLUMN_COURSE_PREREQUISITES, course.prerequisites)
            put(COLUMN_COURSE_DESCRIPTION, course.description)
        }

        val rowsAffected = db.update(
            TABLE_COURSES,
            values,
            "$COLUMN_ID = ?",
            arrayOf(course.id.toString())
        )

        db.close()
        return rowsAffected
    }

    fun deleteCourse(id: Long): Int {
        val db = dbHelper.writableDatabase
        val rowsAffected = db.delete(
            TABLE_COURSES,
            "$COLUMN_ID = ?",
            arrayOf(id.toString())
        )

        db.close()
        return rowsAffected
    }

    private fun cursorToCourse(cursor: Cursor): Course {
        val idIndex = cursor.getColumnIndex(COLUMN_ID)
        val codeIndex = cursor.getColumnIndex(COLUMN_COURSE_CODE)
        val nameIndex = cursor.getColumnIndex(COLUMN_COURSE_NAME)
        val creditsIndex = cursor.getColumnIndex(COLUMN_COURSE_CREDITS)
        val prereqIndex = cursor.getColumnIndex(COLUMN_COURSE_PREREQUISITES)
        val descIndex = cursor.getColumnIndex(COLUMN_COURSE_DESCRIPTION)

        return Course(
            id = cursor.getLong(idIndex),
            code = cursor.getString(codeIndex),
            name = cursor.getString(nameIndex),
            credits = cursor.getInt(creditsIndex),
            prerequisites = cursor.getString(prereqIndex),
            description = cursor.getString(descIndex)
        )
    }
}