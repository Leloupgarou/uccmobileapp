package com.example.uccitmobileapp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.fragment.app.Fragment
import com.example.uccitmobileapp.R
import com.example.uccitmobileapp.databinding.FragmentWebViewBinding

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.webkit.*
import java.net.URISyntaxException

class FacebookFragment : Fragment() {

    private var _binding: FragmentWebViewBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWebViewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupWebView("https://www.facebook.com/uccjamaica")
    }

    private fun setupWebView(url: String) {
        binding.webView.apply {
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url.toString()
                    return handleUrl(view, url)
                }

                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    return handleUrl(view, url)
                }

                private fun handleUrl(view: WebView?, url: String?): Boolean {
                    if (url == null) return false

                    // Handle various URL schemes
                    return when {
                        url.startsWith("intent://") -> handleIntentUrl(url, view)
                        url.startsWith("fb://") || url.contains("facebook.com/dialog/oauth") -> {
                            // Handle both direct fb:// links and OAuth redirects
                            view?.loadUrl("https://m.facebook.com/uccjamaica")
                            true
                        }
                        else -> false
                    }
                }

                private fun handleIntentUrl(url: String, view: WebView?): Boolean {
                    try {
                        val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                        val fallbackUrl = intent.getStringExtra("browser_fallback_url")

                        try {
                            startActivity(intent)
                        } catch (e: ActivityNotFoundException) {
                            fallbackUrl?.let { view?.loadUrl(it) }
                                ?: view?.loadUrl("https://m.facebook.com/uccjamaica")
                        }
                        return true
                    } catch (e: URISyntaxException) {
                        view?.loadUrl("https://m.facebook.com/uccjamaica")
                        return true
                    }
                }
            }

            webChromeClient = createWebChromeClient(binding.progressBar)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false

                // Set mobile user agent to prevent redirects
                userAgentString = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36"

                // Allow mixed content
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

                // Enable better caching
                cacheMode = WebSettings.LOAD_DEFAULT

                // Additional settings to handle Facebook better
                allowContentAccess = true
                databaseEnabled = true
                setGeolocationEnabled(false)
            }

            // Enable third-party cookies
            CookieManager.getInstance().apply {
                setAcceptThirdPartyCookies(binding.webView, true)
                setAcceptCookie(true)
            }

            loadUrl(url)
        }
    }

    private fun createWebChromeClient(progressBar: ProgressBar) = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            progressBar.progress = newProgress
            progressBar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class TwitterFragment : Fragment() {

    private var _binding: FragmentWebViewBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWebViewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupWebView("https://twitter.com/uccjamaica")
    }

    private fun setupWebView(url: String) {
        binding.webView.apply {
            webViewClient = WebViewClient()
            webChromeClient = createWebChromeClient(binding.progressBar)
            settings.javaScriptEnabled = true
            loadUrl(url)
        }
    }

    private fun createWebChromeClient(progressBar: ProgressBar) = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            progressBar.progress = newProgress
            progressBar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class InstagramFragment : Fragment() {

    private var _binding: FragmentWebViewBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWebViewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupWebView("https://www.instagram.com/uccjamaica")
    }

    private fun setupWebView(url: String) {
        binding.webView.apply {
            webViewClient = WebViewClient()
            webChromeClient = createWebChromeClient(binding.progressBar)
            settings.javaScriptEnabled = true
            loadUrl(url)
        }
    }

    private fun createWebChromeClient(progressBar: ProgressBar) = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            progressBar.progress = newProgress
            progressBar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}