package com.example.uccitmobileapp.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "ucc_it.db"
        private const val DATABASE_VERSION = 1

        // Table Names
        const val TABLE_COURSES = "courses"
        const val TABLE_STAFF = "staff"

        // Common Column Names
        const val COLUMN_ID = "id"

        // Courses Table Columns
        const val COLUMN_COURSE_CODE = "code"
        const val COLUMN_COURSE_NAME = "name"
        const val COLUMN_COURSE_CREDITS = "credits"
        const val COLUMN_COURSE_PREREQUISITES = "prerequisites"
        const val COLUMN_COURSE_DESCRIPTION = "description"

        // Staff Table Columns
        const val COLUMN_STAFF_NAME = "name"
        const val COLUMN_STAFF_POSITION = "position"
        const val COLUMN_STAFF_PHONE = "phone"
        const val COLUMN_STAFF_EMAIL = "email"
        const val COLUMN_STAFF_PHOTO = "photo"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create Courses table
        val CREATE_COURSES_TABLE = "CREATE TABLE $TABLE_COURSES (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_COURSE_CODE TEXT, " +
                "$COLUMN_COURSE_NAME TEXT, " +
                "$COLUMN_COURSE_CREDITS INTEGER, " +
                "$COLUMN_COURSE_PREREQUISITES TEXT, " +
                "$COLUMN_COURSE_DESCRIPTION TEXT)"
        db.execSQL(CREATE_COURSES_TABLE)

        // Create Staff table
        val CREATE_STAFF_TABLE = "CREATE TABLE $TABLE_STAFF (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_STAFF_NAME TEXT, " +
                "$COLUMN_STAFF_POSITION TEXT, " +
                "$COLUMN_STAFF_PHONE TEXT, " +
                "$COLUMN_STAFF_EMAIL TEXT, " +
                "$COLUMN_STAFF_PHOTO TEXT)"
        db.execSQL(CREATE_STAFF_TABLE)

        // Prepopulate with sample data
        populateSampleData(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Drop older tables if they exist
        db.execSQL("DROP TABLE IF EXISTS $TABLE_COURSES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_STAFF")

        // Create tables again
        onCreate(db)
    }

    private fun populateSampleData(db: SQLiteDatabase) {
        // Sample Courses
        val courses = arrayOf(
            arrayOf("ITT101", "Introduction to Information Technology", 3, "None", "Fundamental concepts of information technology including computer hardware, software, and data communications."),
            arrayOf("ITT201", "Database Design and Implementation", 3, "ITT101", "Database design principles, normalization, SQL, and implementation of database systems."),
            arrayOf("ITT250", "Web Development", 3, "ITT101", "HTML, CSS, JavaScript, and frameworks for building web applications."),
            arrayOf("ITT301", "Software Engineering", 3, "ITT201", "Principles and practices of software development life cycle."),
            arrayOf("ITT315", "Mobile Application Development", 3, "ITT250", "Development of mobile applications for iOS and Android platforms."),
            arrayOf("ITT320", "Network Security", 3, "ITT101", "Security principles, cryptography, and network security protocols."),
            arrayOf("ITT350", "Cloud Computing", 3, "ITT201", "Concepts and practices of cloud computing services and deployment models."),
            arrayOf("ITT410", "Artificial Intelligence", 3, "ITT301", "Machine learning, neural networks, and AI algorithms."),
            arrayOf("ITT420", "IT Project Management", 3, "ITT301", "Project management methodologies and tools for IT projects."),
            arrayOf("ITT450", "IT Capstone Project", 4, "ITT420", "Integrative project applying IT knowledge to solve real-world problems.")
        )

        // Insert courses
        for (course in courses) {
            val sql = "INSERT INTO $TABLE_COURSES ($COLUMN_COURSE_CODE, $COLUMN_COURSE_NAME, " +
                    "$COLUMN_COURSE_CREDITS, $COLUMN_COURSE_PREREQUISITES, $COLUMN_COURSE_DESCRIPTION) " +
                    "VALUES ('${course[0]}', '${course[1]}', ${course[2]}, '${course[3]}', '${course[4]}')"
            db.execSQL(sql)
        }

        // Sample Staff
        val staff = arrayOf(
            arrayOf("Dr. Jane Smith", "Department Head", "876-555-1234", "j.smith@ucc.edu.jm", "staff_jane_smith.jpg"),
            arrayOf("Prof. John Doe", "Professor", "876-555-2345", "j.doe@ucc.edu.jm", "staff_john_doe.jpg"),
            arrayOf("Dr. Alice Johnson", "Lecturer", "876-555-3456", "a.johnson@ucc.edu.jm", "staff_alice_johnson.jpg"),
            arrayOf("Mr. Robert Brown", "Assistant Lecturer", "876-555-4567", "r.brown@ucc.edu.jm", "staff_robert_brown.jpg"),
            arrayOf("Ms. Sarah Wilson", "IT Lab Coordinator", "876-555-5678", "s.wilson@ucc.edu.jm", "staff_sarah_wilson.jpg"),
            arrayOf("Mr. David Lee", "Technical Support Specialist", "876-555-6789", "d.lee@ucc.edu.jm", "staff_david_lee.jpg"),
            arrayOf("Dr. Emily Clark", "Research Coordinator", "876-555-7890", "e.clark@ucc.edu.jm", "staff_emily_clark.jpg")
        )

        // Insert staff
        for (member in staff) {
            val sql = "INSERT INTO $TABLE_STAFF ($COLUMN_STAFF_NAME, $COLUMN_STAFF_POSITION, " +
                    "$COLUMN_STAFF_PHONE, $COLUMN_STAFF_EMAIL, $COLUMN_STAFF_PHOTO) " +
                    "VALUES ('${member[0]}', '${member[1]}', '${member[2]}', '${member[3]}', '${member[4]}')"
            db.execSQL(sql)
        }
    }
}