package com.example.uccitmobileapp.adapter

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.uccitmobileapp.R
import com.example.uccitmobileapp.data.StaffMember

class DirectoryAdapter(private var staffList: List<StaffMember>) :
    RecyclerView.Adapter<DirectoryAdapter.StaffViewHolder>() {

    class StaffViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nameTextView: TextView = view.findViewById(R.id.text_name)
        val positionTextView: TextView = view.findViewById(R.id.text_position)
        val phoneTextView: TextView = view.findViewById(R.id.text_phone)
        val emailTextView: TextView = view.findViewById(R.id.text_email)
        val photoImageView: ImageView = view.findViewById(R.id.image_photo)
        val callButton: Button = view.findViewById(R.id.button_call)
        val emailButton: Button = view.findViewById(R.id.button_email)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StaffViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_directory, parent, false)
        return StaffViewHolder(view)
    }

    override fun onBindViewHolder(holder: StaffViewHolder, position: Int) {
        val staffMember = staffList[position]

        holder.nameTextView.text = staffMember.name
        holder.positionTextView.text = staffMember.position
        holder.phoneTextView.text = staffMember.phoneNumber
        holder.emailTextView.text = staffMember.email

        // Load image using Glide
        Glide.with(holder.photoImageView.context)
            .load(getDrawableResourceId(holder.photoImageView.context, staffMember.photoUrl))
            .placeholder(R.drawable.ic_person)
            .error(R.drawable.ic_person)
            .circleCrop()
            .into(holder.photoImageView)

        // Set click listeners for call and email buttons
        holder.callButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:${staffMember.phoneNumber}")
            }
            it.context.startActivity(intent)
        }

        holder.emailButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "message/rfc822"
                putExtra(Intent.EXTRA_EMAIL, arrayOf(staffMember.email))
                putExtra(Intent.EXTRA_SUBJECT, "")
            }
            it.context.startActivity(Intent.createChooser(intent, "Send email using..."))
        }
    }

    override fun getItemCount() = staffList.size

    fun updateStaffList(newStaffList: List<StaffMember>) {
        staffList = newStaffList
        notifyDataSetChanged()
    }

    private fun getDrawableResourceId(context: android.content.Context, imageName: String): Int {
        // Remove extension if it exists
        val name = imageName.substringBeforeLast(".")
        return context.resources.getIdentifier(name, "drawable", context.packageName)
    }
}