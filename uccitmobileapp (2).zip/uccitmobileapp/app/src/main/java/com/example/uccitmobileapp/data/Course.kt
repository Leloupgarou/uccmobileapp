package com.example.uccitmobileapp.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Course(
    val id: Long = 0,
    val code: String,
    val name: String,
    val credits: Int,
    val prerequisites: String,
    val description: String
) : Parcelable