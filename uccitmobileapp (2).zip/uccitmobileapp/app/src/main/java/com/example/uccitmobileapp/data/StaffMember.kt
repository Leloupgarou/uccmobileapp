package com.example.uccitmobileapp.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class StaffMember(
    val id: Long = 0,
    val name: String,
    val position: String,
    val phoneNumber: String,
    val email: String,
    val photoUrl: String
) : Parcelable